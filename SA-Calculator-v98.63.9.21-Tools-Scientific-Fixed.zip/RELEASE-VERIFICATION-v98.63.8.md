# Release verification — v98.63.8

Release scope: home calculator display/key sizing and currency/unit picker selected-only behavior.

Required checks: full Node regression suite, production Android web bundle rebuild, YAML parse, ZIP integrity.

Device limitation: no physical Android APK installation or visual inspection was performed in this environment.
