# QA results — v98.63.9.20

## Automated verification
- Release regression suite: **35/35 passed, 0 failed**.
- JavaScript syntax (`assets/js/app.js`, generated `www/assets/js/app.js`): PASS.
- Service worker syntax (source and generated bundle): PASS.
- Android web bundle: PASS — 13 required assets verified.
- GitHub Actions YAML parse: PASS.
- ZIP integrity: PASS.
- Release identity: `1.98.68-v98.63.9.20`; Android workflow versionCode `1098068`.

## Video-derived interaction checks
- Scientific drawer overlays only the main keypad band; it does not cover the main display.
- Normal keypad stays full width; no 46/54 split or shrink is applied.
- Drawer width is 90% (92% on narrow phones), matching the reference's narrow exposed keypad strip.
- Pointer drag updates the drawer position continuously; release settles by distance or velocity.
- Reverse swipe closes the drawer; Escape and close control remain available.
- Scientific 4×4 function matrix and shared-expression insertion are covered by release tests.

## Not yet device-certified
Physical Android installation, OEM gesture-conflict behaviour, real touch latency/frame pacing, and pixel comparison on the user's handset still require a fresh APK run on the device. These are not represented as passed by source-level tests.

## Follow-up micro-audit of the supplied workflow and release package

- Corrected a source-selection race: same-version ZIP candidates now extract to isolated, archive-specific temporary directories.
- Corrected README release notes that incorrectly described the rejected 46/54 split as the shipped layout.
- Release regression gate rerun after adding two workflow/documentation regression checks: 37/37 passed.
- Android web bundle generation rerun: passed; 13 required assets verified.
- Full archived historical corpus diagnostic: 353/425 passed; 72 assertions still encode obsolete release IDs, superseded layouts, or older runtime expectations. These are not part of `npm test` and must not be represented as current release verification.
- No APK was built in this environment because Android SDK/Gradle native build tooling is not configured here. Physical-device touch latency and OEM gesture behavior remain unverified.
